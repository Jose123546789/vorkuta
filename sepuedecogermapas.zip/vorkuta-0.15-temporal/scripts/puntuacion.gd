extends Label

func _process(delta):
	text = "Puntos = " + str(GlobalScript.enemigos_muertos)
