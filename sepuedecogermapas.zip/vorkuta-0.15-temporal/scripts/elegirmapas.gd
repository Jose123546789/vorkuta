extends Control

func _on_nieve_pressed():
	get_tree().change_scene_to_file("res://escenas/mapa.tscn")
	GlobalScript.pociones_vida = 3
	GlobalScript.enemigos_muertos = 0
	GlobalScript.weapon = 1
	GlobalScript.velocidad = 200
	GlobalScript.attack_damage = 1
	GlobalScript.cooldown_arma = 0.5
	GlobalScript.puntuacion_total = 0
	GlobalScript.vida_maxima = 10

func _on_castillo_pressed() -> void:
	get_tree().change_scene_to_file("res://escenas/mapa1.tscn")
	GlobalScript.pociones_vida = 3
	GlobalScript.enemigos_muertos = 0
	GlobalScript.weapon = 1
	GlobalScript.velocidad = 200
	GlobalScript.attack_damage = 1
	GlobalScript.cooldown_arma = 0.5
	GlobalScript.puntuacion_total = 0
	GlobalScript.vida_maxima = 10
