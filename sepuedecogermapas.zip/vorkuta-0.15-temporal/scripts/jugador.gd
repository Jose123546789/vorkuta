extends Node2D

@onready var brazo : Node2D = $Brazo
@onready var arma : Sprite2D = $Brazo/Palo

func _process(delta):
	var target_position = get_global_mouse_position()
	brazo.look_at(target_position)
	arma.flip_h = target_position.x < global_position.x
