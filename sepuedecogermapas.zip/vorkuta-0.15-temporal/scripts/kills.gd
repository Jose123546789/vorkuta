extends Label

func _process(delta):
	text = "Puntuacion = " + str(GlobalScript.puntuacion_total)
