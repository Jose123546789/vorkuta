extends CharacterBody2D

var cooldown = false

func _physics_process(delta):
	if GlobalScript.weapon == 1:
		$palo.show()
		$espada.hide()
	if GlobalScript.weapon == 2:
		$palo.hide()
		$espada.show()
	$cooldown_arma.wait_time = GlobalScript.cooldown_arma

	if Input.is_action_just_pressed("palo"):
		GlobalScript.weapon = 1
	if Input.is_action_just_pressed("espada") and GlobalScript.enemigos_muertos >= 10:
		GlobalScript.weapon = 2

	if Input.is_action_just_pressed("atacar") and GlobalScript.weapon == 1 and cooldown == false:
		atacar()
		await $animation_arma.animation_finished == ("atacar")
		cooldown = true
	if Input.is_action_just_pressed("atacar") and GlobalScript.weapon == 2 and cooldown == false:
		atacar_espada()
		await $animation_arma.animation_finished == ("atacar_espada")
		cooldown = true

func _on_cooldown_arma_timeout():
	cooldown = false

func arma():
	pass

func atacar():
	$animation_arma.play("atacar")
	$animation_arma.play("desatacar")

func atacar_espada():
	$animation_arma.play("atacar_espada")
	$animation_arma.play("desatacar_espada")
