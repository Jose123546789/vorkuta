extends CharacterBody2D

@onready var _arm : Node2D = $Brazo
@onready var _weapon : Node2D = $Brazo/arma
@onready var barra_vida = $CanvasLayer/barra_vida_jugador

var enemy_in_range = false
var fuego_in_range = false

var cooldown = true
var alive = true
var perimeter_radius:float
var direccion = "no"
var vida = 10

func jugador():
	pass

func _process(delta):
	if Input.is_action_just_pressed("pausar"):
		get_tree().change_scene_to_file("res://escenas/menu.tscn")
	barra_vida.value = vida
	var target_position = get_global_mouse_position()
	_arm.look_at(target_position)
	player_movement(delta)
	ataque_enemigo()
	ataque_fuego()
	curacion()
	if vida <= 0:
		alive = false
		vida = 0
		print("has muerto bobo")
		self.queue_free()
		get_tree().change_scene_to_file("res://escenas/game_over.tscn")


func set_antorcha(direction: String):
	var directions = ["right", "left", "north", "south"]
	for dir in directions:
		var antorcha = $Personaje1.get_node_or_null("antorcha_" + dir)
		if antorcha:
			antorcha.visible = (dir == direction)
func antorcha_derecha():
	set_antorcha("right")
func antorcha_izquierda():
	set_antorcha("left")
func antorcha_norte():
	set_antorcha("north")
func antorcha_sur():
	set_antorcha("south")

func player_movement(delta):
	if Input.is_action_pressed("right"):
		direccion = "right"
		play_anim(1)
		velocity.x = GlobalScript.velocidad
		velocity.y = 0
		antorcha_derecha()
	elif Input.is_action_pressed("left"):
		direccion = "left"
		play_anim(1)
		velocity.x = -GlobalScript.velocidad
		velocity.y = 0
		antorcha_izquierda()
	elif Input.is_action_pressed("down"):
		direccion = "down"
		play_anim(1)
		velocity.x = 0
		velocity.y = GlobalScript.velocidad
		antorcha_sur()
	elif Input.is_action_pressed("up"):
		direccion = "up"
		play_anim(1)
		velocity.x = 0
		velocity.y = -GlobalScript.velocidad
		antorcha_norte()
	else:
		velocity.x = 0
		velocity.y = 0
		play_anim(0)
	
	move_and_slide()
	
	#ayuda

func play_anim(movement):
	var direccion_actual = direccion
	var anim = $Personaje1

	if direccion == "right":
		anim.flip_h = false
		if movement == 1:
			anim.play("right")
		elif movement == 0:
			anim.play("right_idle")

	if direccion == "left":
		anim.flip_h = false
		if movement == 1:
			anim.play("left")
		elif movement == 0:
			anim.play("left_idle")

	if direccion == "down":
		anim.flip_h = false
		if movement == 1:
			anim.play("south")
		elif movement == 0:
			anim.play("south_idle")

	if direccion == "up":
		anim.flip_h = false
		if movement == 1:
			anim.play("north")
		elif movement == 0:
			anim.play("north_idle")

func _on_hitbox_body_entered(body: CharacterBody2D):
	if body.has_method("enemigoreal"):
		enemy_in_range = true
	if body.has_method("fuegofatuo"):
		fuego_in_range = true
		
func _on_hitbox_body_exited(body: CharacterBody2D):
	if body.has_method("enemigoreal"):
		enemy_in_range = false
	if body.has_method("fuegofatuo"):
		fuego_in_range = false

func ataque_enemigo():
	if enemy_in_range and cooldown == true:
		vida = vida - 2
		cooldown = false
		$cooldown.start()
		print(vida)

func ataque_fuego():
	if fuego_in_range and cooldown == true:
		vida = vida - 4
		cooldown = false
		$cooldown.start()
		print(vida)

func curacion():
	if Input.is_action_just_pressed("pocion_vida") and GlobalScript.pociones_vida > 0 and vida < GlobalScript.vida_maxima:
		vida = vida + 1
		GlobalScript.pociones_vida = GlobalScript.pociones_vida - 1

func _on_cooldown_timeout():
	cooldown = true
