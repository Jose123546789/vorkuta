extends Node

var player_current_attack = false

var attack_damage = 1
var pociones_vida = 3
var timer_spawn_enemigo = 2
var enemigos_muertos = 0
var weapon = 1
var velocidad = 200
var cooldown_arma = 0.5
var puntuacion_total = 0
var vida_maxima = 10
