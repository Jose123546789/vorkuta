extends Button

func _on_pressed():
	get_tree().paused = true
	hide()
	$"../despausar".show()
