extends Label

func _physics_process(delta):
	botones()
	print(GlobalScript.velocidad)

func botones():
	if GlobalScript.enemigos_muertos >= 10 and GlobalScript.weapon == 1:
		$espada.show()

func _on_espada_pressed():
	if GlobalScript.enemigos_muertos >= 10 and GlobalScript.weapon == 1:
		GlobalScript.weapon = 2
		GlobalScript.attack_damage = GlobalScript.attack_damage + 1
		GlobalScript.enemigos_muertos = GlobalScript.enemigos_muertos - 10
		$espada.hide()

func _on_velocidad_pressed():
	if GlobalScript.enemigos_muertos >= 1:
		GlobalScript.velocidad = GlobalScript.velocidad + 5
		GlobalScript.enemigos_muertos = GlobalScript.enemigos_muertos - 1

func _on_daño_pressed():
	if GlobalScript.enemigos_muertos >= 8:
		GlobalScript.attack_damage = GlobalScript.attack_damage + 1
		GlobalScript.enemigos_muertos = GlobalScript.enemigos_muertos - 8

func _on_cooldown_pressed():
	if GlobalScript.enemigos_muertos >= 2:
		GlobalScript.cooldown_arma = GlobalScript.cooldown_arma * 0.75
		GlobalScript.enemigos_muertos = GlobalScript.enemigos_muertos - 2

func _on_vida_pressed():
	if GlobalScript.enemigos_muertos >= 4:
		GlobalScript.vida_maxima = GlobalScript.vida_maxima + 1
		GlobalScript.enemigos_muertos = GlobalScript.enemigos_muertos - 4
