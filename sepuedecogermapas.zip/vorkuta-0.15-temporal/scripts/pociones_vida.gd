extends Label

func _process(delta):
	text = "Pociones de vida = " + str(GlobalScript.pociones_vida)
