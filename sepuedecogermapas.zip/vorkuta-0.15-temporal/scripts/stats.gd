extends Label

func _process(delta):
	text = "Velocidad = " + str(GlobalScript.velocidad) + "\n" + \
		   "Daño = " + str(GlobalScript.attack_damage) + "\n" + \
		   "Cooldown = " + str(GlobalScript.cooldown_arma) + "\n" + \
		   "Vida Maxima = " + str(GlobalScript.vida_maxima)
