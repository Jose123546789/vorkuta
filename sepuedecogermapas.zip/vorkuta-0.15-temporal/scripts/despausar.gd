extends Button

func _on_pressed():
	get_tree().paused = false
	hide()
	$"../pausar".show()
