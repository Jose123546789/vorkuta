extends Control

var animation_played = false  

func _physics_process(delta):
	if not animation_played:
		$TextureRect/AnimatedSprite2D.play("muerte")
		animation_played = true

func _on_AnimatedSprite2D_animation_finished():
	$TextureRect/AnimatedSprite2D.stop()
func _on_menu_principal_pressed() -> void:
	get_tree().change_scene_to_file("res://escenas/menu.tscn")
