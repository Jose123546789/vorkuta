extends Control

func _on_volver_pressed() -> void:
	get_tree().change_scene_to_file("res://escenas/menu.tscn")


func _on_castillo_pressed() -> void:
	pass # Replace with function body.
