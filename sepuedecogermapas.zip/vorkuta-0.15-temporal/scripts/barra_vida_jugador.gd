extends TextureProgressBar

func _physics_process(delta):
	max_value = GlobalScript.vida_maxima
