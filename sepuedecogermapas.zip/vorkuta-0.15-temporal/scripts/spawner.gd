extends Node2D

@export var enemy_scene : PackedScene
@export var enemy_scene_2 : PackedScene  # Second enemy type
@onready var timer = $Timer

func _physics_process(delta):
	timer.wait_time = GlobalScript.timer_spawn_enemigo

func _on_timer_timeout():
	var enemy = null

	# 75% chance for enemy_scene, 25% for enemy_scene_2
	if randf() < 0.75:
		enemy = enemy_scene.instantiate()
	else:
		enemy = enemy_scene_2.instantiate()

	enemy.global_position = get_random_offscreen_position()
	add_child(enemy)

func get_random_offscreen_position() -> Vector2:
	var space_state = get_world_2d().direct_space_state
	var screen = get_viewport().get_visible_rect()
	var margin = 20
	var max_attempts = 10

	for i in range(max_attempts):
		var x = 0.0
		var y = 0.0

		match randi() % 4:
			0:
				x = randf_range(screen.position.x, screen.end.x)
				y = screen.position.y - margin
			1:
				x = randf_range(screen.position.x, screen.end.x)
				y = screen.end.y + margin
			2:
				x = screen.position.x - margin
				y = randf_range(screen.position.y, screen.end.y)
			3:
				x = screen.end.x + margin
				y = randf_range(screen.position.y, screen.end.y)

		var pos = Vector2(x, y)

		var query = PhysicsPointQueryParameters2D.new()
		query.position = pos
		query.collide_with_areas = false
		query.collide_with_bodies = true

		var result = space_state.intersect_point(query)
		if result.is_empty():
			return pos

	# fallback position if all attempts fail
	return Vector2(screen.position.x - margin, screen.position.y - margin)
